<?php

class blog
{
  private $dbConn;
  //Konstruktor
  function __construct($serverName,$userName,$password,$dbName)
  {
    // Create connection
    $this->dbConn = mysqli_connect($serverName, $userName, $password,$dbName);
    
    // Check connection
    if (!$this->dbConn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    echo "Connected successfully";
  }
}

function dodaj($postDate,$postIntro,$postReadMore,$postReadMore,$postAuthor,$postTitle){
$sql = "INSERT INTO Posts(postDate,postIntro,,postReadMore,postAuthor,postTitle) VALUES ( '$postDate','$postIntro','$postReadMore','$postAuthor,'$postTitle')";
mysqli_query($this->dbConn, $sql);
mysqli_query($this->dbConn);

//$this -> sqlDodaj = "INSERT INTO Posts values (null, '$postDate','$postIntro','$postReadMore','$postAuthor,'$postTitle')";
//$dbQuery=mysqli_query($this -> dbConn ,$this -> sqlDodaj);




}

function usun($idPosts){
  $sql ="DELETE FROM Posts WHERE idPosts=$idPosts";
  mysqli_query($this->dbConn, $sql);
mysqli_query($this->dbConn);


}

function edytuj($idPosts,$postDate,$postIntro,$postReadMore,$postAuthor,$postTitle){
  $Edytuj = "UPDATE Posts SET postDate=$postDate,postIntro=$postIntro,postReadMore=$postReadMore,postAuthor=$postAuthor,postTitle=$postTitle WHERE idPosts=$idPosts";

}

$blogTomka= new blog('localhost','root','root','Blog1');
$blogTomka= dodaj('2001-12-12','intro','readmore',2,'title'); //Jeśli mamy konstruktora w klasie to podajemy parametry odrazu przy tworzeniu obiektu


?>