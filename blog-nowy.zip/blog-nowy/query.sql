INSERT INTO Posts VALUES
(null, '2017-01-23','intro 1','readmore 1',1,'title 1' ),
(null, '2017-01-23','intro 2','readmore 2',1,'title 2' ),
(null, '2017-01-23','intro 3','readmore 3',1,'title 3' ),
(null, '2017-01-23','intro 4','readmore 4',1,'title 4' ),
(null, '2017-01-23','intro 5','readmore 5',1,'title 5' ),
(null, '2017-01-23','intro 6','readmore 6',1,'title 6' )